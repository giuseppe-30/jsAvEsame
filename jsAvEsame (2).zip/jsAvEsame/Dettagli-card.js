const result1 = document.getElementById("result")

 const  fetchGet = async() => {
const url =  new URLSearchParams(location.search)

const id = url.get("Array")    
const res = await fetch(`https://striveschool-api.herokuapp.com/api/product/${id}`, {
    method: "GET",   
    headers: { 

       "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NmNjZTNiMmZlN2VmODAwMTUwNjc2MjMiLCJpYXQiOjE3MjQ3MDM2NjYsImV4cCI6MTcyNTkxMzI2Nn0.LC3r5rk8Q56VrX5iPMtHrm-UqXWoglcgkup93J0eALM"
       }
       })
   const risultato2 = await res.json()
      
   console.log(risultato2) 
   creaCard(risultato2, result1) 
       
   
   }
fetchGet()

   


const creaCard = (dataCard, posizione) =>{

    const card = document.createElement("div");
    const boxText = document.createElement("div");
    const titleCard = document.createElement("h3");
    const priceProduct = document.createElement("span");
    const descriptionCard = document.createElement("p");
    const imgCard = document.createElement("img");
    const buy = document.createElement("a")
    const LinkHome = document.createElement("a")

    card.classList.add("styleCard","col-6")
    imgCard.classList.add("card-img-top","col-12")
    boxText.classList.add("card-body","col-6",)
    descriptionCard.classList.add("mb-0","px-2")
    priceProduct.classList.add("ms-5","price")
    LinkHome.classList.add("btn", "btn-info")
    buy.classList.add("btn","btn-danger","mx-5" )
    
    LinkHome.href = "index.html"
    LinkHome.innerText = "HOME"
    buy.innerText = "COMPRA"
    titleCard.innerText = dataCard.name
    priceProduct.innerText = `${dataCard.price}£`
    descriptionCard.innerText = dataCard.description
    imgCard.src = dataCard.imageUrl
    

    card.append(imgCard,boxText)
    boxText.append(titleCard,descriptionCard,priceProduct,buy,LinkHome)
    posizione.append(card)

    buy.addEventListener("click", ()=>{
        Swal.fire("GRAZIE DEL ACUQISTO");
        buy.innerText = "ACUQUISTATO"
    })
}


