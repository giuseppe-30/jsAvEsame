const result = document.getElementById("sezione")
const loader = document.getElementById('loader');
const url = "https://striveschool-api.herokuapp.com/api/product/"
const input = document.getElementById("input")
const carello = document.getElementById("carello")

function hideLoader() {
    loader.style.display = 'none';}
    function showLoader() {
    loader.style.display = 'block';
}


/* fetchGet() crea la chiamata Get usa i dati per crea le card */
 const  fetchGet = async() => {
    const query = input.value
    showLoader();
 
    const res = await fetch(`${url}?name=${query}`, {
    headers: {"content-Type":"application/json",
    

    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NmNjZTNiMmZlN2VmODAwMTUwNjc2MjMiLCJpYXQiOjE3MjQ3MDM2NjYsImV4cCI6MTcyNTkxMzI2Nn0.LC3r5rk8Q56VrX5iPMtHrm-UqXWoglcgkup93J0eALM"
    }
    })
const risultato = await res.json()
    
if(!risultato.ok){
    console.error("errore")
}
console.log(risultato) 
result.innerText = ""
hideLoader()
risultato.forEach(el => { creaCard(el,result)
    
});
}

fetchGet()

/* la funzione creaCard() crea la card con tutte le funzionalita del card*/
const creaCard = (dataCard, posizione) =>{

    const card = document.createElement("div");
    const boxText = document.createElement("div");
    const titleCard = document.createElement("h3");
    const priceProduct = document.createElement("span");
    const buttonCarello = document.createElement("button") 
    const imgCard = document.createElement("img");
    const buttonDettagli = document.createElement("a")


    card.classList.add("card","col-lg-3","col-sm-12","col-md-4")
    imgCard.classList.add("card-img-top")
    boxText.classList.add("card-body","d-flex")
    buttonCarello.classList.add("btn","btn-success")
    buttonDettagli.classList.add( "btn","btn-danger","mx-2")


    titleCard.innerText = dataCard.name
    priceProduct.innerText = dataCard.price
    imgCard.src = dataCard.imageUrl
    buttonDettagli.href = `indexDettagli.html?Array=${ dataCard._id}`
    buttonDettagli.innerText = "DETTAGLI"
    buttonCarello.innerText = "COMPRA"

    
    card.append(imgCard,titleCard,boxText)
    boxText.append(priceProduct,buttonDettagli,buttonCarello)
    posizione.append(card)

  
    buttonCarello.addEventListener("click", () => {
      Swal.fire({
        title: dataCard.name,
        text: "AQUISTATO",
        imageUrl: dataCard.imageUrl,
        imageWidth: 400,
        imageHeight: 200,
        imageAlt: "prodoto selezionato"
      });
      addCarello(dataCard, carello)
      
    
      
})
 }

/*prodotto che andra nel carello addCarello*/ 
 const addCarello = (dataCard, primaCard ) =>{

  const newCard = document.createElement("div")
  const imgCard = document.createElement("img")
  const boxText = document.createElement("div")
  const newTitle = document.createElement("h5")
  const newPrice = document.createElement("p")
  const buttonRemove = document.createElement("button")

  newCard.classList.add("card","precarello")
  imgCard.classList.add("card-img-top",)
  boxText.classList.add("card-body")
  imgCard.src = dataCard.imageUrl
  newPrice.innerText = `£${dataCard.price}`
  buttonRemove.classList.add("btn", "btn-danger")
  buttonRemove.innerText = "REMOVE"
  

  boxText.append( newPrice, buttonRemove)
  newCard.append(imgCard, boxText)
  carello.appendChild(newCard)

  buttonRemove.addEventListener("click" , () =>{
    
    newCard.remove()

  
  })
}



