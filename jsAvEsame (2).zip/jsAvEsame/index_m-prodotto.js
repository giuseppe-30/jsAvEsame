const inputName = document.getElementById("name")
const inputDescriptionCreaCard = document.getElementById("description")
const inputBrandCreaCard = document.getElementById("brand")
let inputPriceCreaCard = document.getElementById("price")
const InputImgCard = document.getElementById("imageUrl")
const priceValue = Number(inputPriceCreaCard)
const buttonRemove = document.getElementById("ELIMINA")
const buttonModifica = document.getElementById("modifica")
const url = new URLSearchParams(location.search)
const id = url.get("Array") 
const result = document.getElementById("result")
const endPoint = "https://striveschool-api.herokuapp.com/api/product/"
const apikey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NmNjZTNiMmZlN2VmODAwMTUwNjc2MjMiLCJpYXQiOjE3MjQ3MDM2NjYsImV4cCI6MTcyNTkxMzI2Nn0.LC3r5rk8Q56VrX5iPMtHrm-UqXWoglcgkup93J0eALM"
const img = document.getElementById("img")

const fetchGet = async  ()=>{
const res = await fetch(`${endPoint}${id}`, {
    method: "GET",
    headers: {"Content-Type":"application/json",

    "Authorization": `Bearer ${apikey}` 
    }
    })
  
    const risultato = await res.json()
    ////qui fare il looder
    
    img.src = risultato.imageUrl
    inputName.value = risultato.name
    inputBrandCreaCard.value = risultato.brand
    inputDescriptionCreaCard.value = risultato.description
    InputImgCard.value = risultato.imageUrl
    inputPriceCreaCard.value = risultato.price
    console.log(risultato)

} 

fetchGet()
const  fetchElimina = async (e)=>{
   e.preventDefault() 
  const resE = await fetch(`${endPoint}${id}`,{
      method: "DELETE",
      headers:{"Content-Type":"application/json",
        "Authorization": `Bearer ${apikey}` 
    }  

    })
  const  deleteRisultato = await resE.json()
  console.log(deleteRisultato)   
  Swal.fire("PRODOTTO ELIMINATO");

} 
buttonRemove.addEventListener("click",fetchElimina)



buttonModifica.addEventListener("click",e =>{
    e.preventDefault()
    const inputNameCreaCard = document.getElementById("name").value
    const inputDescriptionCreaCard = document.getElementById("description").value
    const inputBrandCreaCard = document.getElementById("brand").value
    let inputPriceCreaCard = document.getElementById("price").value
    const InputImgCard = document.getElementById("imageUrl").value
     const priceValue = Number(inputPriceCreaCard)

const products = {name:inputNameCreaCard,
                description:inputDescriptionCreaCard,
                brand:inputBrandCreaCard,
                imageUrl:InputImgCard,
                price:priceValue};

     
        fetch(`https://striveschool-api.herokuapp.com/api/product/${id}`, {
            method: "PUT",
            headers: { "Content-Type":"application/json",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NmNjZTNiMmZlN2VmODAwMTUwNjc2MjMiLCJpYXQiOjE3MjQ3MDM2NjYsImV4cCI6MTcyNTkxMzI2Nn0.LC3r5rk8Q56VrX5iPMtHrm-UqXWoglcgkup93J0eALM"
            },
            body: JSON.stringify(products)
        })
        .then(res => res.json())
        .then( res =>console.log(res) )
        
        Swal.fire("prodotto modificato");


})






