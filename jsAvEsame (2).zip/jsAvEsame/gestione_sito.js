const result = document.getElementById("result")
const loader = document.getElementById('loader');
const  url = "https://striveschool-api.herokuapp.com/api/product/"
const input = document.getElementById("input") 
const query = input.value


function hideLoader() {
  loader.style.display = 'none';}
  function showLoader() {
  loader.style.display = 'block';
}

const fetchGestione = async () =>{
  showLoader()
  const  res = await fetch(`${url}?name=${query}`,{
    headers:{ 
    "Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NmNjZTNiMmZlN2VmODAwMTUwNjc2MjMiLCJpYXQiOjE3MjQ3MDM2NjYsImV4cCI6MTcyNTkxMzI2Nn0.LC3r5rk8Q56VrX5iPMtHrm-UqXWoglcgkup93J0eALM"
    } })

const risultato = await res.json()
   if(!risultato.ok){
    console.error("error")
   } 
console.log(risultato)
result.innerHTML  = ""
hideLoader()
risultato.forEach(element => { cardGestione(element,result)
  
});
} 

fetchGestione()

const cardGestione = (data,posizione) =>{

    const card = document.createElement("div")
    const boxText = document.createElement("div")
    const img = document.createElement("img")
    const modificaProduct = document.createElement("a")
    const title = document.createElement("h5")

    title.innerText = data.name
    modificaProduct.classList.add("btn","btn-danger")
    card.classList.add("card","col-3","m-5","p-0")
    img.classList.add("card-img-top")
    img.src = data.imageUrl
    modificaProduct.href =`index_m-prodotto.html?Array=${data._id}`
    modificaProduct.innerText = "modifica"
    

    card.append(img, title,modificaProduct, )
    posizione.append(card)

}

