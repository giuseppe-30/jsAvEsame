const buttonCreaCard = document.getElementById("crea")

const result = document.getElementById("boxCard")   
const p = document
 buttonCreaCard.addEventListener("click",e =>{
    e.preventDefault()
    const inputNameCreaCard = document.getElementById("name").value
    const inputDescriptionCreaCard = document.getElementById("description").value
    const inputBrandCreaCard = document.getElementById("brand").value
    let inputPriceCreaCard = document.getElementById("price").value
    const InputImgCard = document.getElementById("imageUrl").value
     const priceValue = Number(inputPriceCreaCard)

const products = {name:inputNameCreaCard,
                description:inputDescriptionCreaCard,
                brand:inputBrandCreaCard,
                imageUrl:InputImgCard,
                price:priceValue};

     
        fetch("https://striveschool-api.herokuapp.com/api/product/", {
            method: "POST",
            headers: { "content-Type":"application/json",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NmNjZTNiMmZlN2VmODAwMTUwNjc2MjMiLCJpYXQiOjE3MjQ3MDM2NjYsImV4cCI6MTcyNTkxMzI2Nn0.LC3r5rk8Q56VrX5iPMtHrm-UqXWoglcgkup93J0eALM"
            },
            body: JSON.stringify(products)
        })
        .then(res => res.json())
        .then( (res) =>{console.log(res) 
            cardPost(res,result)
        })
        Swal.fire({
            title: "Sweet!",
            text: "prodotto creato.",
            imageUrl: InputImgCard,
            imageWidth: 300,
            imageHeight: 200,
            imageAlt: "Custom image"
          });


    })


const cardPost = (dataCard,posizine)=>{

    const card = document.createElement("div")
    const img = document.createElement("img")
    const title = document.createElement("h5")
    const price = document.createElement("span")
            
    
    card.classList.add("card")
    img.src = dataCard.imageUrl
    title.innerText = dataCard.name
    price.innerText = `${dataCard.price}£` 

    card.append(img,title,price)
    posizine.append(card)
}










